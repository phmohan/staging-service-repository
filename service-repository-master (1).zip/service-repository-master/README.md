# sample-config
Spring Cloud External Configuration Repository

The service repository contains set of yml files which is accessed by set of services.
